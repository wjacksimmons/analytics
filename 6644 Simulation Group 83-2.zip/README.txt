## Yahtzee Simulator Project Group 83

### Yahtzee Simulator.ipynb - contains all the necessary codebase formatted for use in Jupyter Notebook\

### Yahtzee Simulator.html - same as above, but for html browsing
### Images for HTML - HTML images not appearing properly

### Exports from Jupyter Lab were not working, so an ipynb converter was used. Sorry for the inconvenience!

